
   let numerosSecretos = []; // Mueve esta variable al ámbito global
   let intentos=0;
   let cifrasUsu=0;
   let intentosActuales = 0;
   let resultadoText;
   let btnProbar;


//INICIALIZACIÓN DE VARIABLES Y EVENTOS
window.onload = function () {                               //se ejecuta al cargar la pagina web
    preguntasUsuario()                                      //llamamos a la función para que pregunte con prompt
    resultadoText= document.getElementById("resultado")     
    numerosSecretos = generarNumerosSecretos(cifrasUsu);    // Sin const aquí porque ya está definida globalmente
    console.log(numerosSecretos);  
    crearTablero();
    btnProbar=document.getElementById("btnProbar")
    btnProbar.addEventListener('click', obtenerValor);
    btnReiniciar=document.getElementById("btnReiniciar");
    btnReiniciar.addEventListener('click', reiniciarJuego);
}

//VENTANA EMERGENTE AL INICIAR CON PROMPT
function preguntasUsuario() {                               
    intentos = parseInt(prompt("Numeros de intentos"));     //Convierte a entero con parse int y almacena en la variable intentos
    cifrasUsu = parseInt(prompt("Dime cuantas cifras"));
}


//FUNCION QUE RECIBE CON INPUT DE ACUERDO CON LAS CIFRAS QUE EL USUARIO ELIGIÓ
function cifras(intentoActual) {                            //parámetro con el intentoActual que está siendo ejecutado
    let contenido = "";                                     //esta variable almacenará el html de los campos de entrada que se generarán
    for(let i=0; i<cifrasUsu; i++) {                        //recorre hasta el número de cifras que el usuario eligió
        contenido += `                                      
        <input type="number" id="valorUsuario${intentoActual}${i}" min="0" max="9">`;       //poner num del 0 al 9
    }
    return contenido;
    //variable contenido con id valor usuario, garantizando un id unico, tipo numeros el usuario solo puede
}

//CREA EL TABLERO USANDO LA FUNCION cifras
function crearTablero() {
    let contenido = "";                                     //aquí se generará el contenido
    for(let i=0; i<intentos; i++) {                         //se ejecuta tantas veces como intentos tenga el usuario
        contenido += `<div class="ronda">${cifras(i)}</div>`; // Aquí pasamos el intento actual a cifras y ronda dara forma a las rondas
    }                                                         
    document.getElementById("tablero").innerHTML = contenido;   //asigna el contenido a tablero con un id único, que podremos llamar desde html
}


//FUNCION BOTON VOLVER A JUGAR
function reiniciarJuego(){
    intentosActuales = 0;                                   //se establece en 0 porque empieza de 0
    numerosSecretos = generarNumerosSecretos(cifrasUsu);    //generamos nuevos numeros secretos
    console.log(numerosSecretos);
    crearTablero();
    resultadoText.innerHTML = "";                           //limpiar mensaje anterior
    btnProbar.style.display = '';
    btnReiniciar.style.display = 'none';                    //esto esconde el botón
}





function generarNumerosSecretos(n) {
    const numeros = [];
    while (numeros.length < n) {
        const randomNum = Math.floor(Math.random() * 10);
        if (!numeros.includes(randomNum)) {
            numeros.push(randomNum);
        }
    }
    return numeros;
}

function obtenerValor() {
    if (intentosActuales >= intentos) {
        alert('¡No te quedan más intentos!');
        return;
    }

    let numerosUsuario = [];
    for(let i=0; i<cifrasUsu; i++) {  // <-- Usa cifrasUsu en lugar de 5
        let entradaUsuario = document.getElementById(`valorUsuario${intentosActuales}${i}`);
        
        // Aquí puedes agregar una comprobación para asegurarte de que el elemento existe
        if (!entradaUsuario) {
            console.error(`No se encontró el elemento con ID: valorUsuario${intentosActuales}${i}`);
            return;
        }

        let numero = parseInt(entradaUsuario.value);
        numerosUsuario.push(numero);

        if(numero === numerosSecretos[i]) {
            entradaUsuario.style.backgroundColor = "green";
        } else if(numerosSecretos.includes(numero)) {
            entradaUsuario.style.backgroundColor = "yellow";
        } else {
            entradaUsuario.style.backgroundColor = "red";
        }
    }
    
    if(JSON.stringify(numerosSecretos) === JSON.stringify(numerosUsuario)) {            //final del juego
      
        resultadoText.innerHTML="Has ganado"
        btnProbar.style.display = 'none';
        btnReiniciar.style.display = '';            //muestra el boton volverajugar

    }else  if(intentosActuales+1==intentos){
        // alert("Has perdido, los número eran " + numerosSecretos)
        resultadoText.innerHTML="Has perdido, los números eran " + numerosSecretos
        btnProbar.style.display = 'none';
        btnReiniciar.style.display = '';            //muestra el boton volverajugar también
    }

    


   

    intentosActuales++ // Incrementa el intento actual para la próxima vez que se presione el botón
}
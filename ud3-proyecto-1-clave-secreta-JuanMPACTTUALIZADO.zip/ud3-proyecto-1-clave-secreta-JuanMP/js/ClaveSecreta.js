    //VARIABLES INICIALES
   let numerosSecretos = [];                        //contiene números que jug tiene que adivinar
   let intentos=0;                                  //intentos que tiene el jug
   let cifrasUsu=0;                                 //cant de números que el jug tiene que adivinar
   let intentosActuales = 0;                        //intentos actuales del jug
   let resultadoText;                               //elementos HTML
   let btnProbar;


//EVENTOS
window.onload = function () {                                                               //la primera funcion que se ejecuta al cargar la pagina web, agrega eventos a varios botones y elementos HTML
    document.getElementById("btnConfigurar").addEventListener('click', preguntasUsuario);   //agrega el btnConfigurar || cuando se haga click se ejecutará la función
    resultadoText= document.getElementById("resultado")
    btnProbar=document.getElementById("btnProbar")                                          //se agrega btnProbar
    btnProbar.addEventListener('click', obtenerValor);                                      //cuando se hace click se ejecuta obtenerValor
    document.addEventListener("keydown", function(event){                                   //si se presiona una tecla se activa el evento
        if(event.key === "Enter"){                                                          //si es Enter la tecla se ejecuta obtenerValor
            obtenerValor()
            event.preventDefault();                 //esto evita que el formulario se envie (si esta dentro de un formulario)
        }
    });
    btnReiniciar=document.getElementById("btnReiniciar");
    btnReiniciar.addEventListener('click', reiniciarJuego);
}


//REVISAR
function eventoTeclado(){
    //RECOGEMOS TODOS LOS BOTONES DE CLASE TECLADO
    var botones = document.querySelectorAll(".teclado");
    var inputs = document.querySelectorAll("input");

    //INDICE DEL INPUT ACTUAL
    var inputActual =0;                                     

    //FOR PARA AÑADIR EL EVENTO DE CLICK EN CADA BOTÓN
    for (let i=0;i<botones.length;i++){
        botones[i].addEventListener("click", function(){    //ahora cuando des click, se agrega el número al primer input disponible
            if(inputActual < inputs.length){                //si el input actual no es mayor al total
                inputs[inputActual].value = this.textContent;   //en la variable de inputs totales meto el input actual y le pongo el valor del input que pulso
                inputActual++;                               //suma +1 para cambiar de input
            }
        });
    }
}


//FUNCION CREA TECLADO, GENERA BOTONES Y LOS MUESTRA EN tecladoContainer
function crearTeclado(){
    let boton ="";
    for(let i=0;i<=9;i++){                                        //recorre del 0 al 9
        boton+=  `<button class='teclado'>${i}</button>`          //se asigna la clase teclado a cada botón
    }
    document.getElementById("tecladoContainer").innerHTML=boton;
}



//FUNCION COMENZAR JUEGO. SE LLAMA CUANDO EMPIEZA EL JUEGO Y CUANDO ACABA
//INICIALIZA LLAMANDO A LAS FUNCIONES PARA EMPEZAR EL JUEGO
function comenzarJuego(){
numerosSecretos = generarNumerosSecretos(cifrasUsu);            //global definida (definida antes de los métodos al principio)
crearTablero();
crearTeclado();
btnReiniciar.style.display = 'none';                            //escondemos el botón Reiniciar
eventoTeclado();

}



//VENTANA EMERGENTE AL INICIAR CON PROMPT - (AHORA SIN PROMPT, CON ELEMENTOS HTML)
function preguntasUsuario() {                               
    intentos = document.getElementById("inputIntentos").value;          //almacenan en la variable intentos el value de inputIntentos y Cifras
    console.log(intentos);
    cifrasUsu = document.getElementById("inputCifras").value;


    //COMPRUEBA SI NUM INTENTOS ES MAYOR QUE 6 | COMPRUEBA SI ALGUNO ESTÁ VACÍO O NO ES UN NUMERO
    if(intentos === "" || cifrasUsu === "" || isNaN(intentos) || isNaN(cifrasUsu) || intentos > 6){
        alert("Por favor, ingresa valores válidos. El número de intentos no puede ser mayor a 6");
        return;                                                     //NO EJECUTA SI NO ES VALIDO
    }

    document.getElementById("inputIntentos").style.display = 'none';        //ocultar elementos
    document.getElementById("inputCifras").style.display = 'none';
    document.getElementById("btnConfigurar").style.display = 'none';

    comenzarJuego();                                            //llama a la función si es válido
}



//

 
//FUNCION QUE RECIBE CON INPUT DE ACUERDO CON LAS CIFRAS QUE EL USUARIO ELIGIÓ
function cifras(intentoActual) {                            //parámetro con el intentoActual que está siendo ejecutado
    let contenido = "";                                     //esta variable almacenará el html de los campos de entrada que se generarán
    for(let i=0; i<cifrasUsu; i++) {                        //recorre hasta el número de cifras que el usuario eligió
        contenido += `                                      
        <input type="number" id="valorUsuario${intentoActual}${i}" min="0" max="9">`;       //poner num del 0 al 9
    }
    return contenido;
    //variable contenido con id valor usuario, garantizando un id unico, tipo numeros el usuario solo puede
}

//CREA EL TABLERO USANDO LA FUNCION cifras
function crearTablero() {
    console.log(intentos)
    let contenido = "";                                                 //aquí se generará el contenido
    for(let i=0; i<intentos; i++) {                                     //se ejecuta tantas veces como intentos tenga el usuario
        contenido += `<div class="ronda">${cifras(i)}</div>`; // Aquí pasamos el intento actual a cifras y ronda dara forma a las rondas
    }                                                         
    document.getElementById("tablero").innerHTML = contenido;           //asigna el contenido a tablero con un id único, que podremos llamar desde html
}


//FUNCION BOTON VOLVER A JUGAR
function reiniciarJuego(){
    intentosActuales = 0;                                                   //se establece en 0 porque empieza de 0
    resultadoText.innerHTML = "";                                           //limpiar mensaje anterior
    btnProbar.style.display = '';
    btnReiniciar.style.display = 'none';                                    //esto esconde el botón
    document.getElementById("inputIntentos").style.display = 'initial';
    document.getElementById("inputCifras").style.display = 'initial';
    document.getElementById("btnConfigurar").style.display = 'initial';
    comenzarJuego();
}





function generarNumerosSecretos(n) {
    const numeros = [];                                     //array donde se guardan los números
    while (numeros.length < n) {                            //while mientras el array de num sea menor a la cantidad que el usuario pone
        const randomNum = Math.floor(Math.random() * 10);   //numero aleatorio del 0 al 9
        if (!numeros.includes(randomNum)) {                 //si el num no esta incluido en el array lo meto
            numeros.push(randomNum);
        }
    }
    return numeros;
}

function obtenerValor() {
    if (intentosActuales >= intentos) {
        alert('¡No te quedan más intentos!');
        reiniciarJuego();
        return;
    }

    let numerosUsuario = [];
    for(let i=0; i<cifrasUsu; i++) {  // <-- Usa cifrasUsu en lugar de 5
        let entradaUsuario = document.getElementById(`valorUsuario${intentosActuales}${i}`);

        
        
        // Aquí puedes agregar una comprobación para asegurarte de que el elemento existe
        if (!entradaUsuario) {
            console.error(`No se encontró el elemento con ID: valorUsuario${intentosActuales}${i}`);
            return;
        }



        let numero = parseInt(entradaUsuario.value);        
        console.log(numero)

        if(isNaN(numero)){                          //comprueba si la variable numero tiene contenido válido
            alert('Ingresa un número válido en todos los campos');
            return;
        }

        numerosUsuario.push(numero);
        console.log(numerosUsuario);

        if(numero === numerosSecretos[i]) {
            entradaUsuario.style.backgroundColor = "green";
        } else if(numerosSecretos.includes(numero)) {
            entradaUsuario.style.backgroundColor = "yellow";
        } else {
            entradaUsuario.style.backgroundColor = "red";
        }
    }
    
    if(JSON.stringify(numerosSecretos) === JSON.stringify(numerosUsuario)) {            //final del juego
      
        resultadoText.innerHTML="Has ganado"
        btnProbar.style.display = 'none';
        btnReiniciar.style.display = '';            //muestra el boton volverajugar

    }else if(intentosActuales+1==intentos){
        // alert("Has perdido, los número eran " + numerosSecretos)
        resultadoText.innerHTML="Has perdido, los números eran " + numerosSecretos
        btnProbar.style.display = 'none';
        btnReiniciar.style.display = '';            //muestra el boton volverajugar también
    }

   

    intentosActuales++ // Incrementa el intento actual para la próxima vez que se presione el botón
}